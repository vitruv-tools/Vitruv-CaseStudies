package mir.routines.java2PcmMethod;

import java.io.IOException;
import mir.routines.java2PcmMethod.RoutinesFacade;
import org.eclipse.emf.ecore.EObject;
import org.emftext.language.java.members.Field;
import org.palladiosimulator.pcm.repository.OperationInterface;
import org.palladiosimulator.pcm.repository.OperationRequiredRole;
import org.palladiosimulator.pcm.repository.RepositoryComponent;
import org.palladiosimulator.pcm.repository.impl.RepositoryFactoryImpl;
import tools.vitruv.extensions.dslsruntime.reactions.AbstractRepairRoutineRealization;
import tools.vitruv.extensions.dslsruntime.reactions.ReactionExecutionState;
import tools.vitruv.extensions.dslsruntime.reactions.structure.CallHierarchyHaving;

@SuppressWarnings("all")
public class CreateOperationRequiredRoleCorrespondingToFieldRoutine extends AbstractRepairRoutineRealization {
  private RoutinesFacade actionsFacade;
  
  private CreateOperationRequiredRoleCorrespondingToFieldRoutine.ActionUserExecution userExecution;
  
  private static class ActionUserExecution extends AbstractRepairRoutineRealization.UserExecution {
    public ActionUserExecution(final ReactionExecutionState reactionExecutionState, final CallHierarchyHaving calledBy) {
      super(reactionExecutionState);
    }
    
    public EObject getElement1(final Field field, final OperationInterface operationInterface, final RepositoryComponent repoComponent, final OperationRequiredRole operationRequiredRole) {
      return operationRequiredRole;
    }
    
    public EObject getElement2(final Field field, final OperationInterface operationInterface, final RepositoryComponent repoComponent, final OperationRequiredRole operationRequiredRole) {
      return field;
    }
    
    public void updateOperationRequiredRoleElement(final Field field, final OperationInterface operationInterface, final RepositoryComponent repoComponent, final OperationRequiredRole operationRequiredRole) {
      operationRequiredRole.setRequiredInterface__OperationRequiredRole(operationInterface);
      operationRequiredRole.setRequiringEntity_RequiredRole(repoComponent);
      String _entityName = repoComponent.getEntityName();
      String _plus = ("Component_" + _entityName);
      String _plus_1 = (_plus + "_requires_");
      String _entityName_1 = operationInterface.getEntityName();
      String _plus_2 = (_plus_1 + _entityName_1);
      operationRequiredRole.setEntityName(_plus_2);
    }
  }
  
  public CreateOperationRequiredRoleCorrespondingToFieldRoutine(final ReactionExecutionState reactionExecutionState, final CallHierarchyHaving calledBy, final Field field, final OperationInterface operationInterface, final RepositoryComponent repoComponent) {
    super(reactionExecutionState, calledBy);
    this.userExecution = new mir.routines.java2PcmMethod.CreateOperationRequiredRoleCorrespondingToFieldRoutine.ActionUserExecution(getExecutionState(), this);
    this.actionsFacade = new mir.routines.java2PcmMethod.RoutinesFacade(getExecutionState(), this);
    this.field = field;this.operationInterface = operationInterface;this.repoComponent = repoComponent;
  }
  
  private Field field;
  
  private OperationInterface operationInterface;
  
  private RepositoryComponent repoComponent;
  
  protected void executeRoutine() throws IOException {
    getLogger().debug("Called routine CreateOperationRequiredRoleCorrespondingToFieldRoutine with input:");
    getLogger().debug("   Field: " + this.field);
    getLogger().debug("   OperationInterface: " + this.operationInterface);
    getLogger().debug("   RepositoryComponent: " + this.repoComponent);
    
    OperationRequiredRole operationRequiredRole = RepositoryFactoryImpl.eINSTANCE.createOperationRequiredRole();
    notifyObjectCreated(operationRequiredRole);
    userExecution.updateOperationRequiredRoleElement(field, operationInterface, repoComponent, operationRequiredRole);
    
    addCorrespondenceBetween(userExecution.getElement1(field, operationInterface, repoComponent, operationRequiredRole), userExecution.getElement2(field, operationInterface, repoComponent, operationRequiredRole), "");
    
    postprocessElements();
  }
}
