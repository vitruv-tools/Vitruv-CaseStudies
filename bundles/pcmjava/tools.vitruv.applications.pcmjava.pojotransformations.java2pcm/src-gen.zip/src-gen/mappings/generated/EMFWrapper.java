package mappings.generated;

public final class EMFWrapper {
}
